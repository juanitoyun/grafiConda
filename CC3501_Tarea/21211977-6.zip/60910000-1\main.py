"""
Tarea 2: Personaje Articulado y Poses Dramáticas
CC3501 - Computación Gráfica

Este programa implementa un personaje articulado con grafo de escena,
múltiples poses dramáticas y diferentes configuraciones de cámara.
"""

import pyglet
from pyglet.window import key
from OpenGL.GL import *
import numpy as np
import os

from . import transformations as tr
from .scene_graph import SceneGraphNode
from .geometry import create_cube, create_sphere, create_cylinder

# Configuración de la ventana
WIDTH = 1280
HEIGHT = 720

class ShaderProgram:
    """Maneja la compilación y uso de shaders"""
    
    def __init__(self, vertex_source, fragment_source):
        self.program = self.compile_shader(vertex_source, fragment_source)
    
    def compile_shader(self, vertex_source, fragment_source):
        """Compila los shaders"""
        # Compilar vertex shader
        vertex_shader = glCreateShader(GL_VERTEX_SHADER)
        glShaderSource(vertex_shader, vertex_source)
        glCompileShader(vertex_shader)
        self.check_compile_errors(vertex_shader, "VERTEX")
        
        # Compilar fragment shader
        fragment_shader = glCreateShader(GL_FRAGMENT_SHADER)
        glShaderSource(fragment_shader, fragment_source)
        glCompileShader(fragment_shader)
        self.check_compile_errors(fragment_shader, "FRAGMENT")
        
        # Crear programa
        program = glCreateProgram()
        glAttachShader(program, vertex_shader)
        glAttachShader(program, fragment_shader)
        glLinkProgram(program)
        self.check_compile_errors(program, "PROGRAM")
        
        glDeleteShader(vertex_shader)
        glDeleteShader(fragment_shader)
        
        return program
    
    def check_compile_errors(self, shader, shader_type):
        """Verifica errores de compilación"""
        if shader_type != "PROGRAM":
            success = glGetShaderiv(shader, GL_COMPILE_STATUS)
            if not success:
                info_log = glGetShaderInfoLog(shader)
                print(f"ERROR::SHADER::{shader_type}::COMPILATION_FAILED\n{info_log.decode()}")
        else:
            success = glGetProgramiv(shader, GL_LINK_STATUS)
            if not success:
                info_log = glGetProgramInfoLog(shader)
                print(f"ERROR::PROGRAM::LINKING_FAILED\n{info_log.decode()}")
    
    def use(self):
        """Usa el programa de shaders"""
        glUseProgram(self.program)
    
    def get_program(self):
        """Retorna el ID del programa"""
        return self.program


def create_character():
    """
    Crea el personaje articulado con grafo de escena.
    El personaje tiene más de 6 articulaciones:
    - Torso (raíz)
    - Cabeza
    - Brazo izquierdo (hombro, codo, mano)
    - Brazo derecho (hombro, codo, mano)
    - Pierna izquierda (cadera, rodilla, pie)
    - Pierna derecha (cadera, rodilla, pie)
    Total: 13 articulaciones
    """
    
    # Crear las primitivas geométricas
    cube = create_cube()
    sphere = create_sphere()
    cylinder = create_cylinder()
    
    # Nodo raíz - Torso
    root = SceneGraphNode("root")
    root.transform = tr.translate(0, 0, 0)
    
    # Torso
    torso = root.add_child(SceneGraphNode("torso"))
    torso.mesh = cube
    torso.transform = tr.matmul([
        tr.scale(0.8, 1.2, 0.4)
    ])
    torso.color = [0.2, 0.3, 0.8]  # Azul
    
    # Cuello
    neck = torso.add_child(SceneGraphNode("neck"))
    neck.mesh = cylinder
    neck.transform = tr.matmul([
        tr.translate(0, 0.7, 0),
        tr.scale(0.2, 0.2, 0.2)
    ])
    neck.color = [0.9, 0.7, 0.6]  # Color piel
    
    # Cabeza
    head = neck.add_child(SceneGraphNode("head"))
    head.mesh = sphere
    head.transform = tr.matmul([
        tr.translate(0, 0.4, 0),
        tr.scale(0.6, 0.7, 0.6)
    ])
    head.color = [0.9, 0.7, 0.6]  # Color piel
    
    # Brazo izquierdo - Hombro
    left_shoulder = torso.add_child(SceneGraphNode("left_shoulder"))
    left_shoulder.mesh = sphere
    left_shoulder.transform = tr.matmul([
        tr.translate(-0.5, 0.4, 0),
        tr.scale(0.25, 0.25, 0.25)
    ])
    left_shoulder.color = [0.2, 0.3, 0.8]
    
    # Brazo izquierdo - Parte superior
    left_upper_arm = left_shoulder.add_child(SceneGraphNode("left_upper_arm"))
    left_upper_arm.mesh = cylinder
    left_upper_arm.transform = tr.matmul([
        tr.translate(0, -0.4, 0),
        tr.scale(0.15, 0.8, 0.15)
    ])
    left_upper_arm.color = [0.2, 0.3, 0.8]
    
    # Brazo izquierdo - Codo
    left_elbow = left_upper_arm.add_child(SceneGraphNode("left_elbow"))
    left_elbow.mesh = sphere
    left_elbow.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(1.2, 0.3, 1.2)
    ])
    left_elbow.color = [0.9, 0.7, 0.6]
    
    # Brazo izquierdo - Antebrazo
    left_forearm = left_elbow.add_child(SceneGraphNode("left_forearm"))
    left_forearm.mesh = cylinder
    left_forearm.transform = tr.matmul([
        tr.translate(0, -0.35, 0),
        tr.scale(1.0, 0.7, 1.0)
    ])
    left_forearm.color = [0.9, 0.7, 0.6]
    
    # Brazo izquierdo - Mano
    left_hand = left_forearm.add_child(SceneGraphNode("left_hand"))
    left_hand.mesh = sphere
    left_hand.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(1.3, 0.4, 1.3)
    ])
    left_hand.color = [0.9, 0.7, 0.6]
    
    # Brazo derecho - Hombro
    right_shoulder = torso.add_child(SceneGraphNode("right_shoulder"))
    right_shoulder.mesh = sphere
    right_shoulder.transform = tr.matmul([
        tr.translate(0.5, 0.4, 0),
        tr.scale(0.25, 0.25, 0.25)
    ])
    right_shoulder.color = [0.2, 0.3, 0.8]
    
    # Brazo derecho - Parte superior
    right_upper_arm = right_shoulder.add_child(SceneGraphNode("right_upper_arm"))
    right_upper_arm.mesh = cylinder
    right_upper_arm.transform = tr.matmul([
        tr.translate(0, -0.4, 0),
        tr.scale(0.15, 0.8, 0.15)
    ])
    right_upper_arm.color = [0.2, 0.3, 0.8]
    
    # Brazo derecho - Codo
    right_elbow = right_upper_arm.add_child(SceneGraphNode("right_elbow"))
    right_elbow.mesh = sphere
    right_elbow.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(1.2, 0.3, 1.2)
    ])
    right_elbow.color = [0.9, 0.7, 0.6]
    
    # Brazo derecho - Antebrazo
    right_forearm = right_elbow.add_child(SceneGraphNode("right_forearm"))
    right_forearm.mesh = cylinder
    right_forearm.transform = tr.matmul([
        tr.translate(0, -0.35, 0),
        tr.scale(1.0, 0.7, 1.0)
    ])
    right_forearm.color = [0.9, 0.7, 0.6]
    
    # Brazo derecho - Mano
    right_hand = right_forearm.add_child(SceneGraphNode("right_hand"))
    right_hand.mesh = sphere
    right_hand.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(1.3, 0.4, 1.3)
    ])
    right_hand.color = [0.9, 0.7, 0.6]
    
    # Pierna izquierda - Cadera
    left_hip = torso.add_child(SceneGraphNode("left_hip"))
    left_hip.mesh = sphere
    left_hip.transform = tr.matmul([
        tr.translate(-0.25, -0.7, 0),
        tr.scale(0.25, 0.25, 0.25)
    ])
    left_hip.color = [0.1, 0.1, 0.1]
    
    # Pierna izquierda - Muslo
    left_thigh = left_hip.add_child(SceneGraphNode("left_thigh"))
    left_thigh.mesh = cylinder
    left_thigh.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(0.2, 1.0, 0.2)
    ])
    left_thigh.color = [0.1, 0.1, 0.1]
    
    # Pierna izquierda - Rodilla
    left_knee = left_thigh.add_child(SceneGraphNode("left_knee"))
    left_knee.mesh = sphere
    left_knee.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(1.2, 0.3, 1.2)
    ])
    left_knee.color = [0.9, 0.7, 0.6]
    
    # Pierna izquierda - Pantorrilla
    left_shin = left_knee.add_child(SceneGraphNode("left_shin"))
    left_shin.mesh = cylinder
    left_shin.transform = tr.matmul([
        tr.translate(0, -0.45, 0),
        tr.scale(0.9, 0.9, 0.9)
    ])
    left_shin.color = [0.1, 0.1, 0.1]
    
    # Pierna izquierda - Pie
    left_foot = left_shin.add_child(SceneGraphNode("left_foot"))
    left_foot.mesh = cube
    left_foot.transform = tr.matmul([
        tr.translate(0, -0.5, 0.1),
        tr.scale(0.3, 0.2, 0.5)
    ])
    left_foot.color = [0.3, 0.2, 0.1]
    
    # Pierna derecha - Cadera
    right_hip = torso.add_child(SceneGraphNode("right_hip"))
    right_hip.mesh = sphere
    right_hip.transform = tr.matmul([
        tr.translate(0.25, -0.7, 0),
        tr.scale(0.25, 0.25, 0.25)
    ])
    right_hip.color = [0.1, 0.1, 0.1]
    
    # Pierna derecha - Muslo
    right_thigh = right_hip.add_child(SceneGraphNode("right_thigh"))
    right_thigh.mesh = cylinder
    right_thigh.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(0.2, 1.0, 0.2)
    ])
    right_thigh.color = [0.1, 0.1, 0.1]
    
    # Pierna derecha - Rodilla
    right_knee = right_thigh.add_child(SceneGraphNode("right_knee"))
    right_knee.mesh = sphere
    right_knee.transform = tr.matmul([
        tr.translate(0, -0.5, 0),
        tr.scale(1.2, 0.3, 1.2)
    ])
    right_knee.color = [0.9, 0.7, 0.6]
    
    # Pierna derecha - Pantorrilla
    right_shin = right_knee.add_child(SceneGraphNode("right_shin"))
    right_shin.mesh = cylinder
    right_shin.transform = tr.matmul([
        tr.translate(0, -0.45, 0),
        tr.scale(0.9, 0.9, 0.9)
    ])
    right_shin.color = [0.1, 0.1, 0.1]
    
    # Pierna derecha - Pie
    right_foot = right_shin.add_child(SceneGraphNode("right_foot"))
    right_foot.mesh = cube
    right_foot.transform = tr.matmul([
        tr.translate(0, -0.5, 0.1),
        tr.scale(0.3, 0.2, 0.5)
    ])
    right_foot.color = [0.3, 0.2, 0.1]
    
    # Retornar el grafo de escena y los nodos articulables
    return {
        'root': root,
        'torso': torso,
        'head': head,
        'left_shoulder': left_shoulder,
        'left_elbow': left_elbow,
        'left_hand': left_hand,
        'right_shoulder': right_shoulder,
        'right_elbow': right_elbow,
        'right_hand': right_hand,
        'left_hip': left_hip,
        'left_knee': left_knee,
        'left_foot': left_foot,
        'right_hip': right_hip,
        'right_knee': right_knee,
        'right_foot': right_foot,
    }


class Pose:
    """Representa una pose del personaje con su configuración de cámara"""
    
    def __init__(self, name, joint_rotations, camera_config):
        self.name = name
        self.joint_rotations = joint_rotations
        self.camera_config = camera_config


def get_poses():
    """
    Define las 3 poses dramáticas del personaje.
    Cada pose tiene rotaciones para las articulaciones y configuración de cámara.
    """
    
    # Pose 1: "The Menacing Stance" - Pose amenazante estilo JoJo
    pose1 = Pose(
        name="The Menacing Stance",
        joint_rotations={
            'torso': tr.rotationY(np.pi / 8),
            'head': tr.matmul([
                tr.translate(0, 0.4, 0),
                tr.rotationZ(-np.pi / 12),
                tr.translate(0, -0.4, 0)
            ]),
            'left_shoulder': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(np.pi / 4),
                tr.rotationX(np.pi / 6)
            ]),
            'left_elbow': tr.matmul([
                tr.translate(0, -0.5, 0),
                tr.rotationZ(np.pi / 3),
                tr.translate(0, 0.5, 0)
            ]),
            'right_shoulder': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(-np.pi / 3),
                tr.rotationX(-np.pi / 4)
            ]),
            'right_elbow': tr.matmul([
                tr.translate(0, -0.5, 0),
                tr.rotationZ(-np.pi / 2.5),
                tr.translate(0, 0.5, 0)
            ]),
            'left_hip': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationX(np.pi / 8)
            ]),
            'right_hip': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationX(-np.pi / 12)
            ]),
        },
        camera_config={
            'eye': np.array([3, 1.5, 4], dtype=np.float32),
            'at': np.array([0, 0.5, 0], dtype=np.float32),
            'up': np.array([0, 1, 0], dtype=np.float32)
        }
    )
    
    # Pose 2: "The Pointing" - Pose señalando dramáticamente
    pose2 = Pose(
        name="The Pointing",
        joint_rotations={
            'torso': tr.rotationY(-np.pi / 6),
            'head': tr.matmul([
                tr.translate(0, 0.4, 0),
                tr.rotationY(np.pi / 6),
                tr.translate(0, -0.4, 0)
            ]),
            'left_shoulder': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(np.pi / 6)
            ]),
            'right_shoulder': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(-np.pi / 2),
                tr.rotationY(np.pi / 4),
                tr.rotationX(-np.pi / 8)
            ]),
            'right_elbow': tr.matmul([
                tr.translate(0, -0.5, 0),
                tr.rotationZ(-np.pi / 6),
                tr.translate(0, 0.5, 0)
            ]),
            'left_hip': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationX(-np.pi / 10),
                tr.rotationZ(np.pi / 12)
            ]),
            'right_hip': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationX(np.pi / 6)
            ]),
            'right_knee': tr.matmul([
                tr.translate(0, -0.5, 0),
                tr.rotationX(np.pi / 8),
                tr.translate(0, 0.5, 0)
            ]),
        },
        camera_config={
            'eye': np.array([4, 0.5, 2], dtype=np.float32),
            'at': np.array([0, 1, 0], dtype=np.float32),
            'up': np.array([0, 1, 0], dtype=np.float32)
        }
    )
    
    # Pose 3: "The Power Stance" - Pose de poder con brazos arriba
    pose3 = Pose(
        name="The Power Stance",
        joint_rotations={
            'torso': tr.identity(),
            'head': tr.matmul([
                tr.translate(0, 0.4, 0),
                tr.rotationX(np.pi / 12),
                tr.translate(0, -0.4, 0)
            ]),
            'left_shoulder': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(np.pi / 2.5),
                tr.rotationY(-np.pi / 6)
            ]),
            'left_elbow': tr.matmul([
                tr.translate(0, -0.5, 0),
                tr.rotationZ(np.pi / 2),
                tr.translate(0, 0.5, 0)
            ]),
            'right_shoulder': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(-np.pi / 2.5),
                tr.rotationY(np.pi / 6)
            ]),
            'right_elbow': tr.matmul([
                tr.translate(0, -0.5, 0),
                tr.rotationZ(-np.pi / 2),
                tr.translate(0, 0.5, 0)
            ]),
            'left_hip': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(np.pi / 12)
            ]),
            'right_hip': tr.matmul([
                tr.translate(0, 0, 0),
                tr.rotationZ(-np.pi / 12)
            ]),
        },
        camera_config={
            'eye': np.array([2, 2, 5], dtype=np.float32),
            'at': np.array([0, 1, 0], dtype=np.float32),
            'up': np.array([0, 1, 0], dtype=np.float32)
        }
    )
    
    return [pose1, pose2, pose3]


def apply_pose(character, pose):
    """Aplica una pose al personaje"""
    # Aplicar las rotaciones a cada articulación
    for joint_name, rotation in pose.joint_rotations.items():
        if joint_name in character:
            joint = character[joint_name]
            # Guardar la transformación base
            base_transform = joint.transform
            # Aplicar rotación
            joint.transform = tr.matmul([rotation, base_transform])


def reset_character_transforms(character):
    """Reinicia las transformaciones del personaje a su estado base"""
    # Recrear el personaje para resetear todas las transformaciones
    return create_character()


class TareaWindow(pyglet.window.Window):
    """Ventana principal de la aplicación"""
    
    def __init__(self):
        super().__init__(WIDTH, HEIGHT, "Tarea 2: Personaje Articulado", resizable=False)
        
        # Configuración de OpenGL
        glClearColor(0.1, 0.1, 0.15, 1.0)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        
        # Cargar shaders
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        with open(os.path.join(current_dir, 'vertex_shader.glsl'), 'r') as f:
            vertex_source = f.read()
        
        with open(os.path.join(current_dir, 'fragment_shader.glsl'), 'r') as f:
            fragment_source = f.read()
        
        self.shader = ShaderProgram(vertex_source, fragment_source)
        
        # Crear el personaje
        self.character = create_character()
        
        # Obtener las poses
        self.poses = get_poses()
        self.current_pose_index = 0
        
        # Aplicar la primera pose
        apply_pose(self.character, self.poses[self.current_pose_index])
        
        # Configuración de la cámara inicial
        self.update_camera()
        
        # Configuración de proyección
        self.projection_matrix = tr.perspective(45, WIDTH / HEIGHT, 0.1, 100)
        
        # Información en consola
        print("=" * 60)
        print("TAREA 2: PERSONAJE ARTICULADO Y POSES DRAMÁTICAS")
        print("=" * 60)
        print(f"Pose actual: {self.poses[self.current_pose_index].name}")
        print("\nControles:")
        print("  ESPACIO: Cambiar entre poses")
        print("  ESC: Salir")
        print("=" * 60)
    
    def update_camera(self):
        """Actualiza la configuración de la cámara según la pose actual"""
        config = self.poses[self.current_pose_index].camera_config
        self.view_matrix = tr.lookAt(config['eye'], config['at'], config['up'])
        self.camera_pos = config['eye']
    
    def on_key_press(self, symbol, modifiers):
        """Maneja las teclas presionadas"""
        if symbol == key.SPACE:
            # Cambiar a la siguiente pose
            self.current_pose_index = (self.current_pose_index + 1) % len(self.poses)
            
            # Recrear el personaje para resetear transformaciones
            self.character = create_character()
            
            # Aplicar la nueva pose
            apply_pose(self.character, self.poses[self.current_pose_index])
            
            # Actualizar cámara
            self.update_camera()
            
            # Mostrar información
            print(f"\nPose cambiada a: {self.poses[self.current_pose_index].name}")
        
        elif symbol == key.ESCAPE:
            self.close()
    
    def on_draw(self):
        """Dibuja la escena"""
        self.clear()
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        # Usar el shader
        self.shader.use()
        program = self.shader.get_program()
        
        # Configurar matrices
        glUniformMatrix4fv(
            glGetUniformLocation(program, "view"),
            1, GL_TRUE, self.view_matrix
        )
        glUniformMatrix4fv(
            glGetUniformLocation(program, "projection"),
            1, GL_TRUE, self.projection_matrix
        )
        
        # Configurar iluminación
        glUniform3f(
            glGetUniformLocation(program, "lightPos"),
            5.0, 5.0, 5.0
        )
        glUniform3f(
            glGetUniformLocation(program, "viewPos"),
            self.camera_pos[0], self.camera_pos[1], self.camera_pos[2]
        )
        
        # Dibujar el personaje
        self.character['root'].draw(program)
        
        # Dibujar un plano de referencia (opcional)
        self.draw_ground(program)
    
    def draw_ground(self, program):
        """Dibuja un plano de referencia en el suelo"""
        # Crear un plano simple
        if not hasattr(self, 'ground_mesh'):
            from .geometry import Mesh
            vertices = np.array([
                -5, -2.5, -5,
                 5, -2.5, -5,
                 5, -2.5,  5,
                -5, -2.5,  5,
            ], dtype=np.float32)
            indices = np.array([0, 1, 2, 2, 3, 0], dtype=np.uint32)
            self.ground_mesh = Mesh(vertices, indices)
        
        glUniformMatrix4fv(
            glGetUniformLocation(program, "model"),
            1, GL_TRUE, tr.identity()
        )
        glUniform3f(
            glGetUniformLocation(program, "color"),
            0.15, 0.15, 0.2
        )
        self.ground_mesh.draw()


def main():
    """Función principal"""
    window = TareaWindow()
    pyglet.app.run()


if __name__ == "__main__":
    main()
